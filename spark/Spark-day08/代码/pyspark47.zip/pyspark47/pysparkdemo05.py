from ml import Pipeline
from ml.classification import DecisionTreeClassifier, DecisionTreeClassificationModel
from ml.evaluation import MulticlassClassificationEvaluator
from ml.feature import StringIndexer, VectorAssembler, IndexToString
from sql import SparkSession


if __name__ == "__main__":
    """
    演示pyspark-决策树分类案例-相亲决策案例
    """
    # 0.创建环境
    spark = SparkSession.builder.appName("pyspark").master("local[*]") \
        .config("spark.sql.shuffle.partitions", "2") \
        .getOrCreate()

    # 0.加载数据
    df = spark.read.format("csv")\
        .option("sep", ",") \
        .option("header", "true") \
        .option("inferSchema", "true") \
        .load("data/appointment.data")
    df.printSchema()
    df.show()

    # 1.标签数值化
    # 设置哪一列是字符串格式的标签列
    # 设置标签数值化之后的列名
    stringIndexer = StringIndexer()\
        .setInputCol("label")\
        .setOutputCol("label_index").fit(df)

    # 2.特征向量化
    # 设置特征列有哪些列
    # 设置特征向量化之后的列名
    vectorAssembler = VectorAssembler() \
        .setInputCols(["age", "handsome", "salary", "programmer"]) \
        .setOutputCol("features")
    # 后续可以使用pipeline做统一的训练和转换,所以这里不需要调用transform


    # 3.构建决策树模型
    # 设置向量化之后的特征列
    # 设置数值化之后的标签列
    # 设置预测列名称(预测出来的是数字)
    decisionTreeClassifier = DecisionTreeClassifier()\
        .setFeaturesCol("features")\
        .setLabelCol("label_index")\
        .setPredictionCol("predict_index")\
        .setMaxDepth(5)
    # 后续可以使用pipeline做统一的训练和转换,所以这里不需要调用fit

    # 4.标签还原
    # 预测出来的标签数值还原为字符串
    # 设置数值化的预测列
    # 设置转为字符串后的预测列的列名
    # 设置数值和字符串的对应关系在哪里
    indexToString = IndexToString().setInputCol("predict_index")\
        .setOutputCol("predict_String")\
        .setLabels(stringIndexer.labels)

    # 5.数据集划分
    trainSet,testSet = df.randomSplit(weights=[0.8,0.2])

    # 6.构建pipeline
    pipeline = Pipeline().setStages([stringIndexer,vectorAssembler,decisionTreeClassifier,indexToString])

    # 7.使用训练集训练
    model = pipeline.fit(trainSet)

    # 8.使用测试集测试模型
    testResult = model.transform(testSet)
    testResult.show()

    # 9.输出决策过程
    print("模型决策过程为: \n %s" % model.stages[2].toDebugString)

    # 10评估模型误差/好坏
    accuracy = MulticlassClassificationEvaluator(labelCol="label_index", predictionCol="predict_index", metricName="accuracy")\
        .evaluate(testResult)
    print("测试集错误率为: %f" % (1.0 - accuracy))

    # model.save("path")
    # model2 =DecisionTreeClassificationModel.load("path")



    spark.stop()