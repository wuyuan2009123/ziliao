from sql import SparkSession
from sql.functions import split, explode

if __name__ == "__main__":
    """
    演示pyspark-SparkSQL
    """
    # 创建环境
    spark = SparkSession.builder.appName("pyspark").master("local[*]").getOrCreate()

    df = spark.read.text("data/words.txt")

    wordsDF = df.select(explode(split(df.value," ")).alias("word"))

    wordsDF.createOrReplaceTempView("t_words")

    spark.sql("select word,count(*) counts from t_words group by word order by counts desc").show()

    wordsDF.groupBy("word").count().orderBy("count", ascending=False).show()

    spark.stop()