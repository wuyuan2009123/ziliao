from sql import SparkSession
from sql.functions import split, explode

if __name__ == "__main__":
    """
    演示pyspark-StructuredStreaming
    """
    # 创建环境
    spark = SparkSession.builder.appName("pyspark").master("local[*]") \
        .config("spark.sql.shuffle.partitions", "2") \
        .getOrCreate()
    df = spark.readStream\
        .format("socket") \
        .option('host', "node1") \
        .option('port', 9999) \
        .load()

    wordsDF = df.select(explode(split(df.value," ")).alias("word"))

    wordsDF.createOrReplaceTempView("t_words")

    result1 = spark.sql("select word,count(*) counts from t_words group by word order by counts desc")

    result2 = wordsDF.groupBy("word").count().orderBy("count", ascending=False)

    result1.writeStream.format("console").outputMode("complete").start()
    result2.writeStream.format("console").outputMode("complete").start().awaitTermination()


    # spark.streams.awaitAnyTermination
    spark.stop()