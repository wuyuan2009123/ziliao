from pyspark import SparkContext
from streaming import StreamingContext

if __name__ == "__main__":
    """
    演示pyspark-SparkStreaming
    """
    # 创建环境
    sc = SparkContext(master="local[*]", appName="pyspark")
    ssc = StreamingContext(sc,5)

    lines = ssc.socketTextStream("node1",9999)
    result = lines.flatMap(lambda line:line.split(" "))\
        .map(lambda word:(word,1))\
        .reduceByKey(lambda a,b:a+b)

    result.pprint()

    ssc.start()
    ssc.awaitTermination()