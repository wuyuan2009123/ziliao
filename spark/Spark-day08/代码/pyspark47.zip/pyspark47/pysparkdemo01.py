from pyspark import SparkContext

if __name__ == "__main__":
    sc = SparkContext(master="local[*]", appName="pyspark")
    lines = sc.textFile("data/words.txt")
    result = lines.flatMap(lambda line:line.split(" "))\
        .map(lambda word:(word,1))\
        .reduceByKey(lambda a,b:a+b)\
        .collect()
    for(word,count) in result:
        print("%s,%i" %(word,count))